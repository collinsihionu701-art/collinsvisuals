// Collins Ihionu — Admin JS (Italiano)

// ─── ACCESSO ──────────────────────────────────────────
function doLogin() {
  const pw = document.getElementById('loginPw').value;
  if (pw === 'CollinXan13@') {
    document.getElementById('admLogin').style.display = 'none';
    document.getElementById('admShell').style.display = 'flex';
    loadAllAdminData();
  } else {
    const input = document.getElementById('loginPw');
    input.style.borderColor = '#e53e3e';
    input.value = '';
    input.placeholder = 'Password errata — riprova';
    setTimeout(() => {
      input.style.borderColor = '';
      input.placeholder = '••••••••';
    }, 2000);
  }
}
function doLogout() {
  document.getElementById('admLogin').style.display = 'flex';
  document.getElementById('admShell').style.display = 'none';
}

// ─── TAB ──────────────────────────────────────────────
function gotoTab(name, el) {
  document.querySelectorAll('.adm-tab').forEach(t => t.style.display = 'none');
  document.querySelectorAll('.adm-navlink').forEach(l => l.classList.remove('active'));
  document.getElementById('tab-' + name).style.display = 'block';
  el.classList.add('active');
}

// ─── CARICA TUTTI I DATI ──────────────────────────────
function loadAllAdminData() {
  loadTextsForm();
  renderAdminProjects();
  renderAdminServices();
  loadImagePreviews();
  loadLogoPreview();
}

// ─── FORM TESTI ───────────────────────────────────────
function loadTextsForm() {
  const t = getTexts();
  const fields = [
    'heroLabel','heroLine1','heroLine2','heroLine3','heroDesc',
    'statYears','statProjects','statClients',
    'aboutTitle','aboutP1','aboutP2','skills',
    'contactTitle','contactSub','contactEmail','contactLocation',
    'socialIG','socialBe','socialLI'
  ];
  fields.forEach(f => {
    const el = document.getElementById('t-' + f);
    if (el) {
      // aboutTitle può contenere HTML (<em>) — mostralo come testo grezzo nell'input
      el.value = (t[f] || '').replace(/<em>/g, '').replace(/<\/em>/g, '');
    }
  });
  // Ripristina il valore raw per aboutTitle (con tag em) nell'input
  const atEl = document.getElementById('t-aboutTitle');
  if (atEl) atEl.value = t.aboutTitle || '';
}

function saveTextsAdmin() {
  const fields = [
    'heroLabel','heroLine1','heroLine2','heroLine3','heroDesc',
    'statYears','statProjects','statClients',
    'aboutTitle','aboutP1','aboutP2','skills',
    'contactTitle','contactSub','contactEmail','contactLocation',
    'socialIG','socialBe','socialLI'
  ];
  const t = getTexts();
  fields.forEach(f => {
    const el = document.getElementById('t-' + f);
    if (el) t[f] = el.value;
  });
  saveTexts(t);
  showSaved('textSaved');
}

// ─── PROGETTI ─────────────────────────────────────────
function renderAdminProjects() {
  const list = document.getElementById('adminProjList');
  const projects = getProjects();
  if (!projects.length) {
    list.innerHTML = '<p class="adm-empty">Nessun progetto ancora. Aggiungine uno!</p>';
    return;
  }
  list.innerHTML = projects.map(p => `
    <div class="adm-item">
      <div class="adm-item-img" style="background-image:url('${p.img || ''}')"></div>
      <div class="adm-item-body">
        <strong>${p.title}</strong>
        <span>${p.category} · ${p.year}</span>
      </div>
      <div class="adm-item-actions">
        <button class="btn-outline small" onclick="openProjectForm(${p.id})">Modifica</button>
        <button class="btn-danger small" onclick="deleteProject(${p.id})">Elimina</button>
      </div>
    </div>
  `).join('');
}

function openProjectForm(id) {
  document.getElementById('projModal').classList.add('open');
  clearProjForm();
  if (id) {
    const p = getProjects().find(p => p.id === id);
    if (!p) return;
    document.getElementById('projFormTitle').textContent = 'Modifica Progetto';
    document.getElementById('pf-title').value  = p.title;
    document.getElementById('pf-cat').value    = p.category;
    document.getElementById('pf-year').value   = p.year;
    document.getElementById('pf-desc').value   = p.description;
    document.getElementById('pf-imgUrl').value = p.img || '';
    document.getElementById('pf-imgData').value = '';
    document.getElementById('pf-editId').value  = id;
    if (p.img) {
      document.getElementById('projImgPreview').style.backgroundImage = `url('${p.img}')`;
      document.getElementById('projImgPreview').style.display = 'block';
      document.getElementById('projUploadPrompt').style.display = 'none';
    }
  }
}
function closeProjectForm() {
  document.getElementById('projModal').classList.remove('open');
  clearProjForm();
}
function clearProjForm() {
  document.getElementById('pf-title').value   = '';
  document.getElementById('pf-cat').value     = 'Identità di Marca';
  document.getElementById('pf-year').value    = new Date().getFullYear();
  document.getElementById('pf-desc').value    = '';
  document.getElementById('pf-imgUrl').value  = '';
  document.getElementById('pf-imgData').value = '';
  document.getElementById('pf-editId').value  = '';
  document.getElementById('projFormTitle').textContent = 'Nuovo Progetto';
  document.getElementById('projImgPreview').style.display = 'none';
  document.getElementById('projUploadPrompt').style.display = 'flex';
}

let projImgProcessing = false;
let projImgProcessingPromise = Promise.resolve();

async function handleProjImg(e) {
  const file = e.target.files[0];
  if (!file) return;
  projImgProcessing = true;
  projImgProcessingPromise = (async () => {
    const data = await optimizeImageForStorage(file, 1400, 0.82);
    if (!data) {
      alert("Impossibile leggere l'immagine selezionata.");
      return;
    }
    document.getElementById('pf-imgData').value = data;
    document.getElementById('pf-imgUrl').value  = '';
    document.getElementById('projImgPreview').style.backgroundImage = `url('${data}')`;
    document.getElementById('projImgPreview').style.display = 'block';
    document.getElementById('projUploadPrompt').style.display = 'none';
  })();

  try {
    await projImgProcessingPromise;
  } finally {
    projImgProcessing = false;
  }
}
function previewFromUrl() {
  const url = document.getElementById('pf-imgUrl').value;
  if (url) {
    document.getElementById('pf-imgData').value = '';
    document.getElementById('projImgPreview').style.backgroundImage = `url('${url}')`;
    document.getElementById('projImgPreview').style.display = 'block';
    document.getElementById('projUploadPrompt').style.display = 'none';
  }
}

async function saveProject() {
  if (projImgProcessing) {
    await projImgProcessingPromise;
  }
  const editId  = document.getElementById('pf-editId').value;
  const imgData = document.getElementById('pf-imgData').value;
  const imgUrl  = document.getElementById('pf-imgUrl').value;
  const img = imgData || imgUrl || '';

  const proj = {
    id:          editId ? parseInt(editId) : null,
    title:       document.getElementById('pf-title').value,
    category:    document.getElementById('pf-cat').value,
    year:        document.getElementById('pf-year').value,
    description: document.getElementById('pf-desc').value,
    img
  };
  if (!proj.title) return alert('Inserisci un titolo per il progetto.');

  const projects = getProjects();
  if (editId) {
    const idx = projects.findIndex(p => p.id === parseInt(editId));
    if (idx !== -1) projects[idx] = { ...projects[idx], ...proj };
  } else {
    proj.id = nextId(projects);
    projects.push(proj);
  }
  if (!saveProjects(projects)) {
    // localStorage quota: prova a ridurre l'immagine base64 e salva di nuovo.
    if (typeof img === 'string' && img.startsWith('data:image/')) {
      const smaller = await shrinkDataUrlForStorage(img, 1000, 0.7);
      if (smaller) {
        const fallbackProj = { ...proj, img: smaller };
        if (editId) {
          const idx = projects.findIndex(p => p.id === parseInt(editId));
          if (idx !== -1) projects[idx] = { ...projects[idx], ...fallbackProj };
        } else {
          projects[projects.length - 1] = fallbackProj;
        }
        if (saveProjects(projects)) {
          renderAdminProjects();
          closeProjectForm();
          return;
        }
      }
    }
    alert("Salvataggio non riuscito: immagine troppo pesante per il browser. Usa un'immagine più leggera o un URL.");
    return;
  }
  renderAdminProjects();
  closeProjectForm();
}

function deleteProject(id) {
  if (!confirm('Eliminare questo progetto?')) return;
  saveProjects(getProjects().filter(p => p.id !== id));
  renderAdminProjects();
}

// ─── SERVIZI ──────────────────────────────────────────
function renderAdminServices() {
  const list = document.getElementById('adminSvcList');
  const svcs = getServices();
  if (!svcs.length) {
    list.innerHTML = '<p class="adm-empty">Nessun servizio ancora.</p>';
    return;
  }
  list.innerHTML = svcs.map(s => `
    <div class="adm-item">
      <div class="adm-item-body" style="flex:1">
        <strong>${s.name}</strong>
        <span>${s.price || ''}</span>
      </div>
      <div class="adm-item-actions">
        <button class="btn-outline small" onclick="openServiceForm(${s.id})">Modifica</button>
        <button class="btn-danger small" onclick="deleteService(${s.id})">Elimina</button>
      </div>
    </div>
  `).join('');
}

function openServiceForm(id) {
  document.getElementById('svcModal').classList.add('open');
  document.getElementById('sf-name').value   = '';
  document.getElementById('sf-desc').value   = '';
  document.getElementById('sf-price').value  = '';
  document.getElementById('sf-editId').value = '';
  document.getElementById('svcFormTitle').textContent = 'Nuovo Servizio';
  if (id) {
    const s = getServices().find(s => s.id === id);
    if (!s) return;
    document.getElementById('svcFormTitle').textContent = 'Modifica Servizio';
    document.getElementById('sf-name').value   = s.name;
    document.getElementById('sf-desc').value   = s.desc;
    document.getElementById('sf-price').value  = s.price || '';
    document.getElementById('sf-editId').value = id;
  }
}
function closeSvcForm() {
  document.getElementById('svcModal').classList.remove('open');
}

function saveService() {
  const editId = document.getElementById('sf-editId').value;
  const svc = {
    name:  document.getElementById('sf-name').value,
    desc:  document.getElementById('sf-desc').value,
    price: document.getElementById('sf-price').value
  };
  if (!svc.name) return alert('Inserisci il nome del servizio.');
  const svcs = getServices();
  if (editId) {
    const idx = svcs.findIndex(s => s.id === parseInt(editId));
    if (idx !== -1) svcs[idx] = { ...svcs[idx], ...svc };
  } else {
    svc.id = nextId(svcs);
    svcs.push(svc);
  }
  saveServices(svcs);
  renderAdminServices();
  closeSvcForm();
}

function deleteService(id) {
  if (!confirm('Eliminare questo servizio?')) return;
  saveServices(getServices().filter(s => s.id !== id));
  renderAdminServices();
}

// ─── LOGO ─────────────────────────────────────────────
function loadLogoPreview() {
  const logoImg = getLogoImg();
  if (logoImg) {
    const preview = document.getElementById('logoImgPreview');
    if (!preview) return;
    preview.style.backgroundImage = `url('${logoImg}')`;
    preview.style.display = 'block';
    document.getElementById('logoUploadPrompt').style.display = 'none';
    if (!logoImg.startsWith('data:')) {
      document.getElementById('logoImgUrl').value = logoImg;
    }
  }
}

function handleLogoImg(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    const data = ev.target.result;
    const preview = document.getElementById('logoImgPreview');
    preview.style.backgroundImage = `url('${data}')`;
    preview.style.display = 'block';
    document.getElementById('logoUploadPrompt').style.display = 'none';
    document.getElementById('logoImgUrl').value = '';
    document.getElementById('logoPendingData').value = data;
  };
  reader.readAsDataURL(file);
}

function previewLogoUrl() {
  const url = document.getElementById('logoImgUrl').value;
  if (url) {
    const preview = document.getElementById('logoImgPreview');
    preview.style.backgroundImage = `url('${url}')`;
    preview.style.display = 'block';
    document.getElementById('logoUploadPrompt').style.display = 'none';
    document.getElementById('logoPendingData').value = '';
  }
}

function saveLogoImgAdmin() {
  const pending = document.getElementById('logoPendingData').value;
  const url     = document.getElementById('logoImgUrl').value;
  const val = pending || url || getLogoImg();
  if (val) {
    saveLogoImg(val);
    showSaved('logoSaved');
  }
}

function removeLogoImgAdmin() {
  if (!confirm('Rimuovere il logo?')) return;
  saveLogoImg(null);
  const preview = document.getElementById('logoImgPreview');
  preview.style.backgroundImage = '';
  preview.style.display = 'none';
  document.getElementById('logoPendingData').value = '';
  document.getElementById('logoImgUrl').value = '';
  document.getElementById('logoUploadPrompt').style.display = 'flex';
  showSaved('logoSaved');
}

// ─── IMMAGINI ─────────────────────────────────────────
function loadImagePreviews() {
  const heroImg  = getHeroImg();
  const aboutImg = getAboutImg();
  if (heroImg) {
    document.getElementById('heroImgPreview').style.backgroundImage = `url('${heroImg}')`;
    document.getElementById('heroImgPreview').style.display = 'block';
    document.getElementById('heroUploadPrompt').style.display = 'none';
    document.getElementById('heroImgUrl').value = heroImg.startsWith('data:') ? '' : heroImg;
  }
  if (aboutImg) {
    document.getElementById('aboutImgPreview').style.backgroundImage = `url('${aboutImg}')`;
    document.getElementById('aboutImgPreview').style.display = 'block';
    document.getElementById('aboutUploadPrompt').style.display = 'none';
    document.getElementById('aboutImgUrl').value = aboutImg.startsWith('data:') ? '' : aboutImg;
  }
}

function handleHeroImg(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    const data = ev.target.result;
    document.getElementById('heroImgPreview').style.backgroundImage = `url('${data}')`;
    document.getElementById('heroImgPreview').style.display = 'block';
    document.getElementById('heroUploadPrompt').style.display = 'none';
    document.getElementById('heroImgUrl').value = '';
    document.getElementById('heroImgPreview').dataset.pending = data;
  };
  reader.readAsDataURL(file);
}
function previewHeroUrl() {
  const url = document.getElementById('heroImgUrl').value;
  if (url) {
    document.getElementById('heroImgPreview').style.backgroundImage = `url('${url}')`;
    document.getElementById('heroImgPreview').style.display = 'block';
    document.getElementById('heroUploadPrompt').style.display = 'none';
    document.getElementById('heroImgPreview').dataset.pending = '';
  }
}
function saveHeroImgAdmin() {
  const pending = document.getElementById('heroImgPreview').dataset.pending;
  const url     = document.getElementById('heroImgUrl').value;
  const val = pending || url || getHeroImg();
  if (val) { saveHeroImg(val); showSaved('heroSaved'); }
}

let aboutImgProcessing = false;
let aboutImgProcessingPromise = Promise.resolve();

async function handleAboutImg(e) {
  const file = e.target.files[0];
  if (!file) return;
  aboutImgProcessing = true;
  aboutImgProcessingPromise = (async () => {
    const data = await optimizeImageForStorage(file);
    if (!data) {
      alert("Impossibile leggere l'immagine selezionata.");
      return;
    }
    document.getElementById('aboutImgPreview').style.backgroundImage = `url('${data}')`;
    document.getElementById('aboutImgPreview').style.display = 'block';
    document.getElementById('aboutUploadPrompt').style.display = 'none';
    document.getElementById('aboutImgUrl').value = '';
    document.getElementById('aboutImgPreview').dataset.pending = data;
  })();

  try {
    await aboutImgProcessingPromise;
  } finally {
    aboutImgProcessing = false;
  }
}
function previewAboutUrl() {
  const url = document.getElementById('aboutImgUrl').value;
  if (url) {
    document.getElementById('aboutImgPreview').style.backgroundImage = `url('${url}')`;
    document.getElementById('aboutImgPreview').style.display = 'block';
    document.getElementById('aboutUploadPrompt').style.display = 'none';
    document.getElementById('aboutImgPreview').dataset.pending = '';
  }
}
async function saveAboutImgAdmin() {
  if (aboutImgProcessing) {
    await aboutImgProcessingPromise;
  }
  const pending = document.getElementById('aboutImgPreview').dataset.pending;
  const url     = document.getElementById('aboutImgUrl').value;
  let val = pending || url || getAboutImg();
  if (!val) return;
  if (saveAboutImg(val)) {
    showSaved('aboutSaved');
    return;
  }
  if (typeof val === 'string' && val.startsWith('data:image/')) {
    const smaller = await shrinkDataUrlForStorage(val, 900, 0.65);
    if (smaller && saveAboutImg(smaller)) {
      document.getElementById('aboutImgPreview').style.backgroundImage = `url('${smaller}')`;
      document.getElementById('aboutImgPreview').dataset.pending = smaller;
      showSaved('aboutSaved');
      return;
    }
  }
  alert("Salvataggio non riuscito: immagine troppo pesante per il browser. Usa un'immagine più leggera o un URL.");
}

// ─── UTILITÀ ──────────────────────────────────────────
function optimizeImageForStorage(file, maxSide = 1400, quality = 0.82) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (ev) => {
      const src = ev.target.result;
      const img = new Image();
      img.onload = () => {
        const longest = Math.max(img.width, img.height);
        const scale = longest > maxSide ? maxSide / longest : 1;
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(src);
          return;
        }
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => resolve(src);
      img.src = src;
    };
    reader.onerror = () => resolve('');
    reader.readAsDataURL(file);
  });
}

function shrinkDataUrlForStorage(dataUrl, maxSide = 900, quality = 0.65) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const longest = Math.max(img.width, img.height);
      const scale = longest > maxSide ? maxSide / longest : 1;
      const w = Math.max(1, Math.round(img.width * scale));
      const h = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve('');
        return;
      }
      ctx.drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => resolve('');
    img.src = dataUrl;
  });
}

function showSaved(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('visible');
  setTimeout(() => el.classList.remove('visible'), 2500);
}
