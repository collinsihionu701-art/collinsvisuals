﻿// Collins Ihionu — Portfolio App JS (Italiano)

document.addEventListener('DOMContentLoaded', () => {
  applyTexts();
  applyImages();
  applyFaviconFromLogo();
  renderProjects();
  renderServices();
  renderProjectTypeOptions();
  initCursor();
  initScrollHeader();
  initMobileNav();
  initReveal();
  document.getElementById('footerYear').textContent = new Date().getFullYear();
});

// ─── TESTI ───────────────────────────────────────────
function applyTexts() {
  const t = getTexts();
  set('heroLabel',    t.heroLabel);
  set('heroLine1',    t.heroLine1);
  set('heroLine2',    t.heroLine2);
  set('heroLine3',    t.heroLine3);
  setHTML('heroDesc', (t.heroDesc || '').replace(/\n/g, '<br>'));
  set('statYears',    t.statYears);
  set('statProjects', t.statProjects);
  set('statClients',  t.statClients);

  const aboutEl = document.getElementById('aboutTitle');
  if (aboutEl) aboutEl.innerHTML = t.aboutTitle;

  const aboutBody = document.getElementById('aboutText');
  if (aboutBody) aboutBody.innerHTML = `<p>${t.aboutP1}</p><p>${t.aboutP2}</p>`;

  const skillsEl = document.getElementById('skillsContainer');
  if (skillsEl && t.skills) {
    skillsEl.innerHTML = t.skills.split(',').map(s => `<span>${s.trim()}</span>`).join('');
  }

  set('contactTitle', t.contactTitle);
  set('contactSub',   t.contactSub);

  const emailEl = document.getElementById('contactEmail');
  if (emailEl) {
    emailEl.textContent = t.contactEmail;
    emailEl.href = 'mailto:' + t.contactEmail;
  }
  set('contactLocation', t.contactLocation);

  const ig = document.getElementById('socialIG');
  const be = document.getElementById('socialBe');
  const li = document.getElementById('socialLI');
  if (ig) ig.href = t.socialIG || '#';
  if (be) be.href = t.socialBe || '#';
  if (li) li.href = t.socialLI || '#';
}

function set(id, val) {
  const el = document.getElementById(id);
  if (el && val !== undefined) el.textContent = val;
}
function setHTML(id, val) {
  const el = document.getElementById(id);
  if (el && val !== undefined) el.innerHTML = val;
}

// ─── IMMAGINI ─────────────────────────────────────────
function applyImages() {
  const heroImg  = getHeroImg();
  const aboutImg = getAboutImg();
  const logoImg  = getLogoImg();
  const heroEl   = document.getElementById('heroImgEl');
  const aboutEl  = document.getElementById('aboutImgEl');
  const logoImgEl  = document.getElementById('logoImg');
  const logoTextEl = document.getElementById('logoText');
  if (heroEl  && heroImg)  heroEl.style.backgroundImage  = `url('${heroImg}')`;
  if (aboutEl && aboutImg) aboutEl.style.backgroundImage = `url('${aboutImg}')`;
  if (logoImgEl) {
    if (logoImg) {
      logoImgEl.src = logoImg;
      logoImgEl.style.display = 'block';
    } else {
      logoImgEl.style.display = 'none';
    }
  }
}

function applyFaviconFromLogo() {
  const logoImg = getLogoImg();
  if (!logoImg) return;

  const ensureIconLink = (sizes) => {
    let link = document.querySelector(`link[rel="icon"][sizes="${sizes}"]`);
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      link.type = 'image/png';
      link.sizes = sizes;
      document.head.appendChild(link);
    }
    return link;
  };

  const buildIcon = (img, size) => {
    const sourceSize = 256;
    const sourceCanvas = document.createElement('canvas');
    sourceCanvas.width = sourceSize;
    sourceCanvas.height = sourceSize;
    const sourceCtx = sourceCanvas.getContext('2d');
    if (!sourceCtx) return null;

    sourceCtx.clearRect(0, 0, sourceSize, sourceSize);
    sourceCtx.imageSmoothingEnabled = true;
    sourceCtx.imageSmoothingQuality = 'high';

    // Keep more breathing room so it matches common favicon visual size.
    const pad = sourceSize * 0.22;
    const maxW = sourceSize - pad * 2;
    const maxH = sourceSize - pad * 2;
    const scale = Math.min(maxW / img.width, maxH / img.height);
    const drawW = img.width * scale;
    const drawH = img.height * scale;
    const drawX = (sourceSize - drawW) / 2;
    const drawY = (sourceSize - drawH) / 2;
    sourceCtx.drawImage(img, drawX, drawY, drawW, drawH);

    let current = sourceCanvas;
    while (current.width / 2 >= size) {
      const half = document.createElement('canvas');
      half.width = Math.max(size, Math.floor(current.width / 2));
      half.height = Math.max(size, Math.floor(current.height / 2));
      const halfCtx = half.getContext('2d');
      if (!halfCtx) break;
      halfCtx.imageSmoothingEnabled = true;
      halfCtx.imageSmoothingQuality = 'high';
      halfCtx.drawImage(current, 0, 0, half.width, half.height);
      current = half;
      if (half.width === size) break;
    }

    if (current.width !== size) {
      const out = document.createElement('canvas');
      out.width = size;
      out.height = size;
      const outCtx = out.getContext('2d');
      if (!outCtx) return null;
      outCtx.imageSmoothingEnabled = true;
      outCtx.imageSmoothingQuality = 'high';
      outCtx.drawImage(current, 0, 0, size, size);
      return out.toDataURL('image/png');
    }

    return current.toDataURL('image/png');
  };

  const img = new Image();
  img.onload = () => {
    const icon32 = buildIcon(img, 32);
    const icon16 = buildIcon(img, 16);
    if (icon32) ensureIconLink('32x32').href = icon32;
    if (icon16) ensureIconLink('16x16').href = icon16;

    let appleIcon = document.querySelector('link[rel="apple-touch-icon"]');
    if (!appleIcon) {
      appleIcon = document.createElement('link');
      appleIcon.rel = 'apple-touch-icon';
      document.head.appendChild(appleIcon);
    }
    appleIcon.href = logoImg;
  };

  img.onerror = () => {
    ensureIconLink('16x16').href = logoImg;
    ensureIconLink('32x32').href = logoImg;
  };

  img.src = logoImg;
}

// ─── PROGETTI ─────────────────────────────────────────
function renderProjects() {
  const grid = document.getElementById('projectsGrid');
  if (!grid) return;
  const projects = getProjects();
  grid.innerHTML = projects.map((p, i) => `
    <article class="proj-card reveal" style="--delay:${i * 80}ms" onclick="openLightbox(${p.id})">
      <div class="proj-img" style="background-image:url('${p.img || ''}')">
        <div class="proj-img-overlay"></div>
      </div>
      <div class="proj-meta">
        <span class="proj-cat">${p.category}</span>
        <h3 class="proj-title">${p.title}</h3>
        <span class="proj-year">${p.year}</span>
      </div>
    </article>
  `).join('');
  observeReveal();
}

// ─── SERVIZI ──────────────────────────────────────────
function renderServices() {
  const list = document.getElementById('servicesList');
  if (!list) return;
  const services = getServices();
  list.innerHTML = services.map((s, i) => `
    <div class="svc-row reveal" style="--delay:${i * 60}ms">
      <div class="svc-num">0${i + 1}</div>
      <div class="svc-body">
        <h3 class="svc-name">${s.name}</h3>
        <p class="svc-desc">${s.desc}</p>
      </div>
      ${s.price ? `<div class="svc-price">${s.price}</div>` : ''}
    </div>
  `).join('');
  observeReveal();
}

function renderProjectTypeOptions() {
  const select = document.getElementById('projectTypeSelect');
  if (!select) return;

  const services = getServices().slice(0, 4);
  const options = services.map((s) => `<option>${s.name}</option>`).join('');
  select.innerHTML = '<option value="">Seleziona...</option>' + options;
}

// ─── LIGHTBOX ─────────────────────────────────────────
function openLightbox(id) {
  const p = getProjects().find(p => p.id === id);
  if (!p) return;
  document.getElementById('lboxImg').style.backgroundImage = `url('${p.img || ''}')`;
  document.getElementById('lboxCat').textContent   = p.category;
  document.getElementById('lboxTitle').textContent = p.title;
  document.getElementById('lboxDesc').textContent  = p.description;
  document.getElementById('lboxYear').textContent  = p.year;
  document.getElementById('lightbox').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  document.getElementById('lightbox').classList.remove('open');
  document.body.style.overflow = '';
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeLightbox(); });

// ─── FORM CONTATTI ────────────────────────────────────
function submitForm(e) {
  e.preventDefault();
  document.getElementById('contactForm').style.display = 'none';
  document.getElementById('formOk').style.display = 'flex';
}

// ─── CURSOR ───────────────────────────────────────────
function initCursor() {
  const cursor = document.getElementById('cursor');
  const dot = document.getElementById('cursorDot');
  if (!cursor || !dot) return;

  // Disable custom cursor on touch devices.
  if (window.matchMedia('(hover: none), (pointer: coarse)').matches) {
    cursor.style.display = 'none';
    dot.style.display = 'none';
    document.body.style.cursor = 'auto';
    return;
  }

  let mx = 0;
  let my = 0;
  let cx = 0;
  let cy = 0;
  let activeMagnet = null;

  cursor.dataset.tool = 'SELECT';

  document.addEventListener('mousemove', (e) => {
    mx = e.clientX;
    my = e.clientY;
  });

  const interactiveSelector = 'a, button, .proj-card, .svc-row, input, textarea, select';
  const magneticSelector = 'a, button, .proj-card, .svc-row, .btn-fill, .btn-link';

  const getToolLabel = (el) => {
    if (el.matches('.proj-card')) return 'VIEW';
    if (el.matches('input, textarea, select')) return 'TYPE';
    if (el.matches('.svc-row')) return 'GRID';
    if (el.matches('button, .btn-fill')) return 'BUILD';
    if (el.matches('a')) return 'NAV';
    return 'MOVE';
  };

  document.querySelectorAll(interactiveSelector).forEach((el) => {
    el.addEventListener('mouseenter', () => {
      cursor.classList.add('hover', 'label-on');
      dot.classList.add('hover');
      cursor.dataset.tool = getToolLabel(el);
      if (el.matches(magneticSelector)) activeMagnet = el;

      if (el.matches('.proj-card')) {
        cursor.classList.add('pen-mode');
        dot.classList.add('pen-mode');
        cursor.dataset.tool = 'PEN';
      }
    });

    el.addEventListener('mouseleave', () => {
      cursor.classList.remove('hover', 'label-on', 'press');
      cursor.classList.remove('pen-mode');
      dot.classList.remove('hover', 'press', 'pen-mode');
      cursor.dataset.tool = 'SELECT';
      activeMagnet = null;
    });
  });

  document.addEventListener('mousedown', () => {
    cursor.classList.add('press');
    dot.classList.add('press');
  });

  document.addEventListener('mouseup', () => {
    cursor.classList.remove('press');
    dot.classList.remove('press');
  });

  (function loop() {
    let tx = mx;
    let ty = my;

    if (activeMagnet) {
      const rect = activeMagnet.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const dx = centerX - mx;
      const dy = centerY - my;
      const dist = Math.hypot(dx, dy);
      const force = Math.max(0, 1 - dist / 260) * 0.35;
      tx = mx + dx * force;
      ty = my + dy * force;
    }

    cx += (tx - cx) * 0.17;
    cy += (ty - cy) * 0.17;
    cursor.style.transform = `translate(${cx - 27}px, ${cy - 27}px)`;
    dot.style.transform = `translate(${mx - 9}px, ${my - 9}px)`;
    requestAnimationFrame(loop);
  })();
}

function initScrollHeader() {
  const header = document.getElementById('siteHeader');
  if (!header) return;
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 60);
  });
}

function initMobileNav() {
  const toggle = document.getElementById('menuToggle');
  const mobileNav = document.getElementById('mobileNav');
  if (!toggle || !mobileNav) return;

  const closeMenu = () => {
    toggle.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
    mobileNav.classList.remove('open');
    document.body.style.overflow = '';
  };

  toggle.addEventListener('click', () => {
    const willOpen = !mobileNav.classList.contains('open');
    toggle.classList.toggle('open', willOpen);
    mobileNav.classList.toggle('open', willOpen);
    toggle.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
    document.body.style.overflow = willOpen ? 'hidden' : '';
  });

  mobileNav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', closeMenu);
  });

  window.addEventListener('resize', () => {
    if (window.innerWidth > 768) closeMenu();
  });
}

// ─── REVEAL ALLO SCROLL ───────────────────────────────
function initReveal() {
  document.querySelectorAll('.reveal').forEach(el => observeEl(el));
}
function observeReveal() {
  document.querySelectorAll('.reveal:not(.visible)').forEach(el => observeEl(el));
}
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.12 });

function observeEl(el) { revealObserver.observe(el); }


