// Collins Ihionu — Data Layer (Italiano)
// Tutti i contenuti salvati in localStorage


const DEFAULTS = {
  texts: {
    heroLabel: 'Visual Designer & Art Director',
    heroLine1: 'Racconto',
    heroLine2: 'storie',
    heroLine3: 'attraverso il design.',
    heroDesc: 'Con base in Italia — lavoro in tutto il mondo.\nIdentità di marca, comunicazione visiva & direzione creativa.',
    statYears: '5+',
    statProjects: '50+',
    statClients: '10+',
    aboutTitle: 'Il design è il modo in cui <em>traduco la visione</em> in realtà.',
    aboutP1: "Sono un graphic designer e narratore visivo con oltre 5 anni di esperienza nella costruzione di brand che si distinguono. Il mio lavoro si trova all'incrocio tra strategia ed estetica — non mi limito a rendere le cose belle, le faccio funzionare.",
    aboutP2: "Da sistemi logo a identità di marca complete, layout editoriali a campagne digitali — ogni progetto che intraprendo riceve il mio pieno investimento creativo. Credo che il grande design non sia decorazione: è comunicazione.",
    skills: 'Illustrator, Photoshop, InDesign, Figma, After Effects, Blender',
    contactTitle: 'Hai un progetto in mente?',
    contactSub: 'Sono sempre disponibile a discutere nuovi lavori creativi. Costruiamo qualcosa di grande insieme.',
    contactEmail: 'collinsdesign04.com',
    contactLocation: 'Italia — Lavoro da remoto in tutto il mondo',
    socialIG: '#',
    socialBe: 'https://twitter.com/',
    socialLI: '#'
  },

  projects: [
    {
      id: 1,
      title: 'Brand Identity Volta',
      category: 'Identità di Marca',
      year: '2024',
      description: 'Sistema di brand completo per Volta, una startup italiana di energia sostenibile. Logo, tipografia, palette colori e linee guida del brand.',
      img: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&q=80'
    },
    {
      id: 2,
      title: 'Serie Editoriale Noir',
      category: 'Editoriale',
      year: '2024',
      description: 'Direzione artistica e layout per una serie editoriale di 12 numeri che esplora l\'arte e la cultura contemporanea.',
      img: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80'
    },
    {
      id: 3,
      title: 'Campagna Meridian',
      category: 'Campagna',
      year: '2023',
      description: 'Campagna visiva completa per Meridian skincare di lusso — direzione fotografica, layout e materiali digitali.',
      img: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&q=80'
    },
    {
      id: 4,
      title: 'Carattere Tipografico Forma',
      category: 'Tipografia',
      year: '2023',
      description: 'Carattere tipografico display personalizzato progettato per uno studio di architettura milanese. Peso variabile e dimensioni ottiche.',
      img: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=800&q=80'
    },
    {
      id: 5,
      title: 'Packaging Kova',
      category: 'Identità di Marca',
      year: '2023',
      description: 'Design del packaging e identità visiva per Kova, un brand alimentare italiano premium. Dal concept ai file pronti per la stampa.',
      img: 'https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?w=800&q=80'
    },
    {
      id: 6,
      title: 'Studio Lunare',
      category: 'Direzione Artistica',
      year: '2022',
      description: "Direzione artistica per la mostra inaugurale di Studio Lunare. Design di manifesti, segnaletica e presenza digitale.",
      img: 'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=800&q=80'
    }
  ],

  services: [
    {
      id: 1,
      name: 'Identità di Marca',
      desc: 'Sistemi di brand completi — logo design, tipografia, palette colori, linee guida del brand e linguaggio visivo scalabile su ogni punto di contatto.',
      price: 'A partire da €1.200'
    },
    {
      id: 2,
      name: 'Direzione Artistica',
      desc: 'Supervisione creativa per campagne, shooting editoriali e progetti visivi. Sviluppo del concept fino all\'esecuzione finale.',
      price: 'A partire da €800'
    },
    {
      id: 3,
      name: 'Design Editoriale',
      desc: 'Layout per libri, riviste, lookbook e pubblicazioni a stampa. Attenzione alla griglia, alla gerarchia e all\'esperienza di lettura.',
      price: 'A partire da €600'
    },
    {
      id: 4,
      name: 'Campagna Visiva',
      desc: 'Design di campagne end-to-end su carta e digitale — dal visual principale agli asset social, OOH e oltre.',
      price: 'A partire da €900'
    }
  ],

  heroImg: null,
  aboutImg: null,
  logoImg: null
};

function getData(key) {
  const storageKey = 'civ_' + key;
  const raw = localStorage.getItem(storageKey);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch (err) {
      console.error('Dato localStorage non valido per', key, err);
      localStorage.removeItem(storageKey);
    }
  }
  return DEFAULTS[key];
}

function setData(key, val) {
  try {
    localStorage.setItem('civ_' + key, JSON.stringify(val));
    return true;
  } catch (err) {
    console.error('Errore salvataggio localStorage per', key, err);
    return false;
  }
}

function getTexts()    { return getData('texts'); }
function getProjects() { return getData('projects'); }
function getServices() { return getData('services'); }
function getHeroImg()  { return getData('heroImg'); }
function getAboutImg() { return getData('aboutImg'); }
function getLogoImg()  { return getData('logoImg'); }

function saveTexts(t)    { return setData('texts', t); }
function saveProjects(p) { return setData('projects', p); }
function saveServices(s) { return setData('services', s); }
function saveHeroImg(v)  { return setData('heroImg', v); }
function saveAboutImg(v) { return setData('aboutImg', v); }
function saveLogoImg(v)  { return setData('logoImg', v); }

function nextId(arr) {
  return arr.length ? Math.max(...arr.map(i => i.id)) + 1 : 1;
}
