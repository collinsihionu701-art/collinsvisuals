﻿# Struttura progetto - sito portfolio

## Panoramica
Progetto statico (frontend) con area pubblica (`index.html`) e pannello amministrazione (`admin.html`).

## Albero cartelle

```text
sitofinale/
  index.html
  admin.html
  assets/
    css/
      style.css
      admin.css
    js/
      data.js
      app.js
      admin.js
    img/
```

## Ruoli dei file
- `index.html`: pagina pubblica del portfolio.
- `admin.html`: pannello di gestione contenuti.
- `assets/css/style.css`: stile principale del sito pubblico.
- `assets/css/admin.css`: stile specifico area admin.
- `assets/js/data.js`: layer dati (`localStorage` + default).
- `assets/js/app.js`: logica frontend lato sito pubblico.
- `assets/js/admin.js`: logica frontend lato pannello admin.
- `assets/img/`: cartella dedicata ad eventuali asset immagine statici.

## Note operative
- Il pannello admin salva in `localStorage` del browser.
- Nessun backend richiesto per il funzionamento base.
- Per deploy su XAMPP: mantenere la root su `sitofinale/`.
